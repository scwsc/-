// 封装规则生成函数
function createRedirectRule(id, urlFilter, resourceTypes = ["main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "xmlhttprequest", "ping", "csp_report", "media", "websocket", "other"]) {
    return {
        id: id,
        priority: 1,
        action: {
            type: "redirect",
            redirect: {
                url: "https://www.baidu.com"
            }
        },
        condition: {
            urlFilter: urlFilter,
            resourceTypes: resourceTypes
        }
    };
}

chrome.runtime.onInstalled.addListener(() => {
    // 定义要匹配的URL过滤器数组
    const urlFilters = [
        "*://*iqiyi.com/player*",
        //"*://*iqiyi.com/dash?tvid=*",
        //"*://*qq.com/proxyhttp",
        "*://*qq.com/getvinfo?charge=0*"
        // 你可以在这里添加更多的URL过滤器，例如
        // "*://anotherdomain.com/*"
    ];

    const rules = [];
    // 循环生成规则
    urlFilters.forEach((filter, index) => {
        rules.push(createRedirectRule(index + 1, filter));
    });

    // 添加规则到动态规则中
    chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: rules.map(rule => rule.id),
        addRules: rules
    });
});