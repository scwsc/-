$(document).ready(function () {
    // 封装替换元素为 iframe 的函数
    function replaceElementWithIframe(elementId) {
        const targetDiv = document.getElementById(elementId);
        if (targetDiv) {
            const iframe = document.createElement('iframe');
            const attributes = targetDiv.attributes;
            for (let i = 0; i < attributes.length; i++) {
                const attr = attributes[i];
                iframe.setAttribute(attr.name, attr.value);
            }
            // 添加 allowfullscreen 属性
            iframe.setAttribute('allowfullscreen', '');

            // 定义多个视频解析接口
            const parsingInterfaces = [
                "https://jx.hls.one/?url=",
                "https://jx.2s0.cn/player/?url=",
                "https://www.yemu.xyz/?url="
            ];
            // 选择第一个解析接口作为初始接口
            let selectedInterface = parsingInterfaces[0];

            // 初始设置 iframe 的 src
            iframe.src = selectedInterface + window.location.href;
            targetDiv.parentNode.replaceChild(iframe, targetDiv);

            // 监听 DOM 变化来捕获地址变化
            const observer = new MutationObserver((mutationsList) => {
                for (const mutation of mutationsList) {
                    if (mutation.type === 'childList' || mutation.type === 'attributes') {
                        // 检查地址是否变化
                        const currentUrl = window.location.href;
                        if (currentUrl!== iframe.src.split('?url=')[1]) {
                            updateIframeSrc(iframe, selectedInterface);
                        }
                    }
                }
            });

            // 配置 MutationObserver，监听文档 body 的变化
            const targetNode = document.body;
            const config = { attributes: true, childList: true, subtree: true };
            observer.observe(targetNode, config);

            // 监听来自选项页面的消息
            chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
                if (message.action === 'updateInterface') {
                    selectedInterface = message.selectedInterface;
                    updateIframeSrc(iframe, selectedInterface);
                }
            });
        }
    }

    function updateIframeSrc(iframe, selectedInterface) {
        // 拼接解析接口和新地址
        const newSrc = selectedInterface + window.location.href;
        iframe.src = newSrc;
    }

    replaceElementWithIframe('player-container');
    //replaceElementWithIframe('container');
    //replaceElementWithIframe('ykPlayer');
});